<?php

/**
 * Pricing tab in WooCommerce product edit tab
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

