<?php

/**
 * View for localization tab
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>

<div class="rp_wcdpd_wrapper">
    <div class="rp_wcdpd_container">
        <div class="rp_wcdpd_left">

            <h3><?php _e('Pricing Rules', 'rp_wcdpd'); ?></h3>
            <div>lalala</div>

            <h3><?php _e('Cart Discounts', 'rp_wcdpd'); ?></h3>
            <div>lalala</div>

            <h3><?php _e('Get In Touch', 'rp_wcdpd'); ?></h3>
            <div>lalala</div>

        </div>
        <div style="clear: both;"></div>
    </div>
</div>